export const ENV = {
  API: 'http://www.razonlegal.co/api/v1'
};
